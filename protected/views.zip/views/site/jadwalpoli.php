<section class="hero-wrap hero-wrap-2" style="background-image: url('<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Jadwal Poliklinik</h1>
          </div>
        </div>
      </div>
    </section>
 <section class="ftco-section ftco-no-pt ftco-no-pb contact-section">
			<div class="container">
				<div class="row d-flex align-items-stretch no-gutters">
					<div class="col-md-12 p-4 p-md-5 order-md-last bg-light">
						<table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Klinik</th>
                  <th>Dokter</th>
                  <th>Hari</th>
                  <th>Jam</th>
                  <!-- <th>CSS grade</th> -->
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Penyakit Dalam</td>
                  <td>Dokter A.</td>
                  <td>Senin</td>
                  <td>08.00-10.00</td>
                </tr>
                <tr>
                  <td>Penyakit Dalam</td>
                  <td>Dokter A.</td>
                  <td>Selasa</td>
                  <td>08.00-10.00</td>
                </tr>
                <tr>
                  <td>Penyakit Dalam</td>
                  <td>Dokter A.</td>
                  <td>Rabu</td>
                  <td>10.00-12.00</td>
                </tr>
                </tbody>
              </table>
					</div>
					
				</div>
			</div>
		</section>

