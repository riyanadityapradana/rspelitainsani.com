<div class="login-box">
  <!-- /.login-logo -->
	<?php $form=$this->beginWidget('CActiveForm', array(
		'id'=>'login-form',
		'enableClientValidation'=>true,
		'clientOptions'=>array(
			'validateOnSubmit'=>true,
		),
	)); ?>
  <div class="login-box-body">
	  <div class="login-logo">
      <img src="<?= Yii::app()->request->baseUrl; ?>/images/logo-xs.png" style="display: block;height: 70px;margin: 0 auto">
	    <a href="<?= Yii::app()->request->baseUrl; ?>" style="color: #3bb3c2"><b>PELITA</b>INSANI</a>
	  </div>
    <form action="../../index2.html" method="post">
      <div class="form-group has-feedback">
      	<?php echo $form->textField($model, 'username', ['type'=>'text','class' => "form-control", 'placeholder' => "Masukkan Username"]); ?>
        <?php echo $form->error($model, 'username',['style'=>'text-align:center']); ?>
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
      	 <?php echo $form->passwordField($model, 'password', ['type'=>'password','class' => "form-control", 'placeholder' => 'Masukkan Password']); ?>
         <?php echo $form->error($model, 'password',['style'=>'text-align:center']); ?>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
			</div>
      <div class="row">

        <!-- /.col -->
        <div class="col-xs-6"></div>
        <div class="col-xs-6">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Masuk</button>
          <a href="<?php echo Yii::app()->request->urlReferrer; ?>" class="btn btn-danger btn-block btn-flat">Kembali</a>
        </div>
        <!-- /.col -->
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
<?php $this->endWidget(); ?>
</div>
