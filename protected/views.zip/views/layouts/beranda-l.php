<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Rumah Sakit Pelita Insani</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet"> 
    <!-- <link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet"> -->

    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/animate.css">
    
    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/magnific-popup.css">

    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/aos.css">

    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/ionicons.min.css">

    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/flaticon.css">
    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/icomoon.css">
    <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/css/style.css">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl; ?>/themes/adminlte/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <link rel="icon" href="<?php echo Yii::app()->request->baseUrl; ?>/images/logo-xs.png" type="image/x-icon">
    <style type="text/css">
    	.ftco-footer {
    		padding: 1em 0 !important;
    	}

      .navbar {
  overflow: hidden;
  background-color: #333;
  position: inherit;
}

.dropdown {
  float: left;
  overflow: hidden;
  position: inherit;
}

.dropdown .dropbtn {
  border: none;
  outline: none;
  font-size: 14px;
  color: #2f89fc;
  padding: 1rem 20px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  z-index: 1;
}

.dropdown-content a {
  float: none;
  padding: 1rem 20px;
  font-size: 14px;
  color: #2f89fc;
  text-decoration: none;
  display: inline-block;
  text-align: left;
}

.dropbtn:hover,
.dropdown-content a:hover {
  background-color: #2f89fc;
  color: #ffffff;
  cursor: pointer;
}

.dropdown:hover .dropdown-content {
  display: block;
}
    </style>
  </head>
  <body>
    <nav class="navbar py-4 navbar-expand-lg ftco_navbar navbar-light bg-light flex-row">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-3 px-md-0" style="width: 100%">
          <div class="col-lg-5 pr-4 align-items-center">
            <a class="navbar-brand" href="index.html"><img src="<?php echo Yii::app()->request->baseUrl; ?>/images/logo-rspi.png" height="80px"></span></a>
          </div>
          <div class="col-lg-7 d-none d-md-block">
            <div class="row d-flex">
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="col-md-6 pr-4 d-flex topper align-items-center">
                  <div class="icon bg-white mr-2 d-flex justify-content-center align-items-center"><span class="icon-map"></span></div>
                  <span class="text">Jl. Sekumpul No. 66 Martapura 70614</span>
                </div>
                <div class="col-md-6 pr-4 d-flex topper align-items-center">
                <div class="icon bg-white mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
                <span class="text">Telp. (0511) 7722210</span>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>

	  <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container d-flex align-items-center">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
	      <p class="button-custom order-lg-last mb-0"><a href="tel:+625114722222" class="btn btn-secondary py-2 px-3"><span class="icon-phone2"></span> IGD: (0511) 4722222</a></p>
	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav mr-auto">
	        	<li class="nav-item"><a href="<?php echo Yii::app()->request->baseUrl; ?>/" class="nav-link">Home</a></li>
	        	<li class="nav-item"><a href="<?php echo Yii::app()->request->baseUrl; ?>/site/tentang" class="nav-link">About Us</a></li>
            <div class="dropdown">
              <button class="dropbtn">LAYANAN</button>
              <div class="dropdown-content">
                <a href="<?php echo Yii::app()->request->baseUrl; ?>/site/fasilitas">FASILITAS</a>
                <a href="<?php echo Yii::app()->request->baseUrl; ?>/site/jadwalpoli">JADWAL POLIKLINIK</a>
              </div>
            </div> 
	        	<li class="nav-item"><a href="<?php echo Yii::app()->request->baseUrl; ?>/site/dokter" class="nav-link">Dokter</a></li>
	          <li class="nav-item"><a href="<?php echo Yii::app()->request->baseUrl; ?>/site/kontak" class="nav-link">Kontak</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <!-- START Content -->
    <?php echo $content ?>
    <!-- END Content -->

    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">

            <p style="margin-bottom: 0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> CV. Borneo Media Teknologi | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
    </div>
</footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/jquery.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/popper.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/bootstrap.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/jquery.easing.1.3.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/jquery.waypoints.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/jquery.stellar.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/owl.carousel.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/jquery.magnific-popup.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/aos.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/jquery.animateNumber.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/bootstrap-datepicker.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/jquery.timepicker.min.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/google-map.js"></script>
  <script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/drcare/js/main.js"></script>
    <!-- DataTables -->
<script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/fixedcolumns/3.2.6/js/dataTables.fixedColumns.min.js"></script>
<script src="<?php echo Yii::app()->request->baseUrl; ?>/themes/adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

<!-- <script>
  $(document).ready(function () {
    $('#example1').DataTable()
  })
</script> -->

  </body>
</html>