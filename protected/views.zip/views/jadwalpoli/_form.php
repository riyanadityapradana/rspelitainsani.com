<?php
/* @var $this JadwalpoliController */
/* @var $model Jadwalpoli */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'jadwalpoli-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'id_jadwal'); ?>
		<?php echo $form->textField($model,'id_jadwal'); ?>
		<?php echo $form->error($model,'id_jadwal'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'klinik'); ?>
		<?php echo $form->textField($model,'klinik',array('size'=>5,'maxlength'=>5)); ?>
		<?php echo $form->error($model,'klinik'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'dokter'); ?>
		<?php echo $form->textField($model,'dokter',array('size'=>20,'maxlength'=>20)); ?>
		<?php echo $form->error($model,'dokter'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'hari'); ?>
		<?php echo $form->textArea($model,'hari',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'hari'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'jam'); ?>
		<?php echo $form->textField($model,'jam'); ?>
		<?php echo $form->error($model,'jam'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->